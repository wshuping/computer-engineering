#ifndef __U1_STRING_H__
#define __U1_STRING_H__

int U1_strSend(char* pc_str,int i_len);
int U1_strRec(char* pc_str,int i_len);

#endif