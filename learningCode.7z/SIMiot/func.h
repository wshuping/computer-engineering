#ifndef __FUNC_H__
#define __FUNC_H__

void delay();
char* strcomb(char* pc_ori,char* pc_add,int i_alen);

#endif